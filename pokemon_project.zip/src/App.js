import Navbar from "./components/Navbar/Navbar";
import Search from "./components/Search/Search";
import Card from "./components/Card/Card";
import style from "./App.module.css";

function randomNum() {
  return Math.floor(Math.random() * 898) + 1;
}

function App() {
  return (
    <div className={style.App}>
      <Navbar />
      <Search />
      <div className={style.cards}>
        <Card pokemon={randomNum()} />
        <Card pokemon={randomNum()} />
        <Card pokemon={randomNum()} />
      </div>
    </div>
  );
}

export default App;
