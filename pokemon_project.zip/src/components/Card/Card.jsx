import axios from "axios";
import { useState, useEffect } from "react";
import style from "./Card.module.css";

function importAll(r) {
  let images = {};
  r.keys().forEach((item, index) => {
    images[item.replace("./", "")] = r(item);
  });
  return images;
}

const images = importAll(
  require.context("../../assets", false, /\.(png|jpe?g|svg)$/)
);

const Card = (props) => {
  const [pokemonName, setName] = useState("");
  const [pokemonType, setType] = useState([]);
  const [pokemonImg, setImg] = useState("");
  const [pokemonAbility, setAbility] = useState([]);

  useEffect(() => {
    axios({
      method: "get",
      url: `https://pokeapi.co/api/v2/pokemon/${props.pokemon}`,
    }).then((res) => {
      setName(res.data.species.name);
      setType(res.data.types.map((type) => type.type.name));
      setImg(res.data.sprites.front_default);
      setAbility(res.data.abilities.map((ability) => ability.ability.name));
    });
  });

  return (
    <div className={style.card}>
      <div className={style.header}>
        <h2 className={style.name}>{pokemonName}</h2>
        <div className={style.icon}>
          {pokemonType.map((type) => (
            <img
              className={style.iconpic}
              src={images[`${type}.png`]}
              alt="type pic"
            ></img>
          ))}
        </div>
      </div>
      <img className={style.img} src={pokemonImg} alt="pic" />
      <div className={style.ability}>
        <h4 className={style.abilities}>Abilities:</h4>
        {pokemonAbility.map((ability) => (
          <span>{ability}</span>
        ))}
      </div>
    </div>
  );
};

export default Card;
